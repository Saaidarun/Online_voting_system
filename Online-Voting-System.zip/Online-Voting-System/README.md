# Online-Voting-System
<p>This is a web application, It can be used for any general purpose Election.</p>
It is up and running here : http://onlinevoting.byethost13.com/index.php

## 🔧 Technologies & Tools
![](https://img.shields.io/badge/FrontEnd-HTML-informational?style=flat&logo=Html&logoColor=white&color=2bbc8a)
![](https://img.shields.io/badge/FrontEnd-CSS-informational?style=flat&logo=CSS&logoColor=white&color=2bbc8a)
![](https://img.shields.io/badge/BackEnd-PHP-informational?style=flat&logo=php&logoColor=white&color=2bbc8a)
![](https://img.shields.io/badge/Database-Mysql-informational?style=flat&logo=mysql&logoColor=white&color=2bbc8a)

<img src="Screenshot (27).png"><br>

<img src="Screenshot (28).png"><br>

<img src="Screenshot (34).png"><br>

<img src="Screenshot (35).png"><br>

<img src="Screenshot (36).png">
