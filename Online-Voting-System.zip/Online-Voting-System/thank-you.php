<!DOCTYPE html>
<html>
<head>
	<title>Than you</title>
</head>

<style>
body{
		margin:0px;
		padding: 0px;
		background-image: url('login.jpg');
	}


.box1{
	width:70%;
	height: 50%;
	text-align: center;
	margin-left:-60px;
	margin-right: 20%;
	margin-top: 60px;
	margin-bottom: 10px;
	color:yellow;

}

.btn{
		margin-left: 88%;
		margin-top: .5%;
		color:black;
}
input{
	padding:10px;
	margin:10px;
	width: 100px;
	background-color: yellow;
	border:2px solid black;
}
input:hover{
	background-color: rgb(220, 202, 19 );
	cursor: pointer;
	color: white;
  
}
</style>
<body>	
	        <div class="btn">

				<table>
					<tr><td><a href="login.php"><input type="submit" name="Back" value="Logout"></a></td></tr>
				</table>
			</div>


		
			<div class="box1">
				<h1>You vote has been counted Now <br>Thank You</h1>
			</div>

			
	


</body>
</html>

