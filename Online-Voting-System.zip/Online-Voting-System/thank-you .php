<!DOCTYPE html>
<html>
<head>
	<title>Than U</title>
</head>

<style>
body{
		margin:0px;
		padding: 0px;
		background-image: url('login.jpg');
	}


.box1{
	width:70%;
	height: 50%;
	text-align: center;
	margin-left: 3%;
	margin-right: 10%;
	margin-top: 150px;
	margin-bottom: 10px;
	color:red;

}
</style>
<body>

		
			<div class="box1">
				<h1>You Vote has been counted Now <br>Thank You</h1>
			</div>

	


</body>
</html>

