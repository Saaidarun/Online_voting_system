<?php
session_start();
if(!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("location: admin_login.php");
    exit;
}

$host = "localhost:3306";
$user = "root";
$pass = "";
$db = "online_voting_system";
$conn = mysqli_connect($host, $user, $pass, $db);

// Get vote counts
$parties = ['bjp', 'congress', 'jdu', 'aap'];
$votes = [];

foreach($parties as $party) {
    $sql = "SELECT COUNT(*) as count FROM votes WHERE LOWER(candidate)=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $party);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    $votes[$party] = $row['count'] ?? 0;
}

mysqli_close($conn);
?>

<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .logout {
            background-color: #ff4444;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
        }
        .results-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        .party-box {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        .party-logo {
            width: 100px;
            height: 80px;
            object-fit: contain;
            margin-bottom: 10px;
        }
        .vote-count {
            font-size: 24px;
            font-weight: bold;
            color: #4CAF50;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Admin Dashboard - Voting Results</h1>
        <a href="logout.php" class="logout">Logout</a>
    </div>
    
    <div class="results-container">
        <div class="party-box">
            <img src="bjp.png" alt="BJP" class="party-logo">
            <h2>BJP</h2>
            <div class="vote-count"><?php echo $votes['bjp']; ?> votes</div>
        </div>
        
        <div class="party-box">
            <img src="congress.png" alt="Congress" class="party-logo">
            <h2>Congress</h2>
            <div class="vote-count"><?php echo $votes['congress']; ?> votes</div>
        </div>
        
        <div class="party-box">
            <img src="jdu.png" alt="JDU" class="party-logo">
            <h2>JDU</h2>
            <div class="vote-count"><?php echo $votes['jdu']; ?> votes</div>
        </div>
        
        <div class="party-box">
            <img src="app.jpg" alt="AAP" class="party-logo">
            <h2>AAP</h2>
            <div class="vote-count"><?php echo $votes['aap']; ?> votes</div>
        </div>
    </div>
</body>
</html> 