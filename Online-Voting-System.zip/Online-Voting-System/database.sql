-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS online_voting_system;
USE online_voting_system;

-- Create registration_detail table
CREATE TABLE registration_detail (
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    city VARCHAR(50) NOT NULL,
    adharcard VARCHAR(12) PRIMARY KEY,
    address TEXT NOT NULL,
    photo VARCHAR(255)
);

-- Create votes table
CREATE TABLE votes (
    candidate VARCHAR(50) NOT NULL,
    adharcard VARCHAR(12) NOT NULL,
    PRIMARY KEY (adharcard),
    FOREIGN KEY (adharcard) REFERENCES registration_detail(adharcard)
);

-- Create admin table
CREATE TABLE admin (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100) NOT NULL
);

-- Insert admin credentials
INSERT INTO admin (username, password) VALUES ('admin', 'admin123'); 