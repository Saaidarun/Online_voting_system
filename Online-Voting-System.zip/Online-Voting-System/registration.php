<!DOCTYPE html>
<html>
	<head>
		<link href="registration.css" rel="stylesheet" type="text/css">
		<title>Registration - Online Voting System</title>
	</head>
  <style>
    ul{
      list-style-type:none;
      background-color:rgb(80, 224, 36);
      overflow:hidden;
    }
    li{
      float:right;
    }
    li a{
      padding:20px;
      display:inline-block;
      text-decoration:none;
      color:black;
    }
    li a:hover{
      background-color:rgb(22, 119, 48);
      color:white;
    }
    .head{
      margin-right:25%;
      color:white;
      float:right;
    }
    .voteImg{
      width:8%;
      height:8%;
      position:absolute;
      top:5%;
    }
    input{
      padding:13px;
      margin-top:10px;
      width: 250px;
    }
    .alert{
      background-color: #ff4444;
      padding: 10px;
      color: white;
      margin: 10px auto;
      text-align: center;
      border-radius: 4px;
    }
    .help-text {
      font-size: 12px;
      color: #666;
      margin-top: 2px;
      display: block;
    }
    .invalid-feedback {
      color: #ff4444;
      font-size: 12px;
      display: none;
    }
    input:invalid + .invalid-feedback {
      display: block;
    }
    .btn {
      background-color: rgb(80, 224, 36);
      color: white;
      cursor: pointer;
      border: none;
      border-radius: 4px;
      margin-top: 20px;
    }
    .btn:hover {
      background-color: rgb(22, 119, 48);
    }
  </style>
<body>
    <ul>
      <li><a href="login.php"><strong>Home</strong></a></li>
      <h3 class="head"><strong>Online Voting System</strong></h3>
      <img class="voteImg" src="vote1.png" style="width:100px; height: 50px; position: absolute;top:6px;left: 13px;">
    </ul> 

  <div class="formoutline">
   	<h3 class="Registration">Registration</h3>

    <?php if(@$_GET['msg']==true) { ?>
      <div class="alert"><?php echo $_GET['msg']; ?></div>
    <?php } ?>

    <?php if(@$_GET['msg2']==true) { ?>
      <div class="alert"><?php echo $_GET['msg2']; ?></div>
    <?php } ?>

   	<div class="form">
   		<form action="project.php" method="post" enctype="multipart/form-data">
   			<table>
   				<tr>
            <td>
              <input type="text" name="name" placeholder="Name*" required
                     pattern="[A-Za-z ]{2,50}" 
                     title="Name should be 2-50 characters long, containing only letters and spaces">
              <span class="help-text">2-50 characters, letters only</span>
            </td>
            <td>
              <input type="tel" name="mobile" placeholder="Mobile*" required
                     pattern="[6-9][0-9]{9}"
                     title="Please enter a valid 10-digit mobile number starting with 6,7,8 or 9">
              <span class="help-text">10 digits, starting with 6,7,8,9</span>
            </td>
          </tr>
   				<tr>
            <td>
              <input type="password" name="pass" placeholder="Password*" required
                     minlength="6"
                     title="Password must be at least 6 characters">
              <span class="help-text">Minimum 6 characters</span>
            </td>
            <td>
              <input type="password" name="confirmpass" placeholder="Confirm password*" required>
              <span class="help-text">Must match password</span>
            </td>
          </tr>
   				<tr>
            <td>
              <input type="text" name="state" placeholder="State*" required
                     pattern="[A-Za-z ]{2,50}"
                     title="Please enter a valid state name">
              <span class="help-text">Enter valid Indian state</span>
            </td>
            <td>
              <input type="text" name="city" placeholder="City*" required
                     pattern="[A-Za-z ]{2,50}"
                     title="Please enter a valid city name">
              <span class="help-text">Enter valid city name</span>
            </td>
          </tr>
   				<tr>
            <td>
              <input type="text" name="adharcard" placeholder="Aadhar Card*" required
                     pattern="[0-9]{12}"
                     title="Please enter a valid 12-digit Aadhar number">
              <span class="help-text">12 digits only</span>
            </td>
            <td>
              <input type="text" name="address" placeholder="Address*" required
                     minlength="10" maxlength="200"
                     title="Address should be between 10-200 characters">
              <span class="help-text">10-200 characters</span>
            </td>
          </tr>
   				<tr>
            <td>
              <input type="file" name="photo" accept="image/jpeg,image/png" required>
              <span class="help-text">JPG/PNG, max 2MB</span>
            </td>
          </tr>	
   			</table>
   			<input class="btn" type="submit" name="register" value="Register">
   		</form>
    </div>
  </div>

  <script>
    // Confirm password validation
    document.querySelector('input[name="confirmpass"]').addEventListener('input', function() {
      const password = document.querySelector('input[name="pass"]').value;
      if(this.value !== password) {
        this.setCustomValidity('Passwords do not match');
      } else {
        this.setCustomValidity('');
      }
    });
  </script>
</body>
</html>
