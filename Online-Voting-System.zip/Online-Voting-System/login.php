<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<style>
body{
	margin:0px;
    padding:0px;
    background-image: url("login.jpg");
    overflow: hidden;
    border-image-repeat: none;
}

ul{
	list-style-type:none;
	background-color:rgb(80, 224, 36);
	overflow:hidden;
}
li{
	float:right;
}
li a{
	padding:20px;
	display:inline-block;
	text-decoration:none;
	color:black;
}
li a:hover{
	background-color:rgb(22, 119, 48  );
	color:white;
}
.head{
	margin-right:35%;
	color:white;
	float:right;
}
.voteImg{
	width:8%;
	height:8%;
	position:absolute;
	top:5%;
}

.login_icon{
	width:20%;
	height: 13%;
	border-radius: 50%;
	margin-left:40%;
	margin-top: 4%;
}
.login_formate{
	width: 25%;
	height: 75%;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	background-color: rgb(91, 86, 88);
	border-radius: 5%;
	padding: 20px;
	box-shadow: 0 0 10px rgba(0,0,0,0.3);
}
input{
	padding:10px;
	margin: 5px;
	border-radius: 5px;
}
.form{
	margin-left:17%;
}
#login{
	margin-left: 20%;
	color:white;
}

.register{
	width:110px;
	color:white;
	background-color: rgb(49, 55, 52  );
}
.register:hover{
	background-color: rgb(7,7,7);
	cursor: pointer;
}
.google{
	width:190px;
	background-color: rgb(215, 82, 36);
}
.google:hover{
    background-color: rgb(217, 56, 0);	
    cursor: pointer;
}
.loginbtn{
	background-color:rgb(14, 73, 151 ); 
	color:white; 
	width:70px;
	cursor: pointer;
}
.alert{
	color:red;
}
</style>

<body>
    <ul>
    	<li><a href="admin_login.php"><strong>Admin Login</strong></a></li>
    	<li><a href="login.php"><strong>Home</strong></a></li>
    	<h3 class="head"><strong>Online Voting System</strong></h3>
    	<img class="voteImg" src="vote1.png" style="width:100px; height: 50px; position: absolute;top:6px;left: 13px;">
    </ul>	

	<div class="login_formate">
		<img class="login_icon" src="login_icon.png">
		<form class="form" action="login_check.php" method="post">
			<table>
				<h3 id="login">Login to vote</h3>
				<?php if(@$_GET['msg']==true) { ?>
					<div class="alert"><strong><?php echo $_GET['msg']; ?></strong></div>
				<?php } ?>
				<tr><td><input type="text" name="adharcard" placeholder="AdharCard No" required></td></tr>
				<tr><td><input type="password" name="password" placeholder="password" required></td></tr>
				<tr><td><p><input class="loginbtn" name="login" type="submit" value="Login"></p></td></tr>
			</table>
		</form>
		<table class="a">
			<tr><td><input class="google" type="submit" value="Sign In with Google"></td></tr>
			<tr><td><h3 style="color:yellow;">New user: <a href="registration.php"><input class="register" type="submit" value="Register"></a></h3></td></tr>
		</table>
	</div>
</body>
</html>