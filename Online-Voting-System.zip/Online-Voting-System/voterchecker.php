<?php


session_start();

                $host="localhost:3306";
				$user="root";
				$pass="";
				$db="online_voting_system";
				$conn=mysqli_connect($host,$user,$pass,$db);

				if (!$conn) {
				    die("Connection failed: " . mysqli_connect_error());
				}

				if(!isset($_SESSION['adhar'])) {
				    header('location:login.php');
				    exit();
				}

				$adharno=$_SESSION['adhar'];
				$party = null;

				// Check if user has already voted
				$sql0 = "SELECT * FROM votes WHERE adharcard=?";
				$stmt = mysqli_prepare($conn, $sql0);
				mysqli_stmt_bind_param($stmt, "s", $adharno);
				mysqli_stmt_execute($stmt);
				$result0 = mysqli_stmt_get_result($stmt);

				if(mysqli_num_rows($result0) >= 1) {
				    header('location:error.php');
				    exit();
				}

				// Determine which party was voted for
				if(isset($_POST['btn1'])) {
				    $party = "bjp";
				} elseif(isset($_POST['btn2'])) {
				    $party = "congress";
				} elseif(isset($_POST['btn3'])) {
				    $party = "jdu";
				} elseif(isset($_POST['btn4'])) {
				    $party = "aap";
				}

				if($party !== null) {
				    // Insert vote using prepared statement
				    $sql = "INSERT INTO votes (candidate, adharcard) VALUES (?, ?)";
				    $stmt = mysqli_prepare($conn, $sql);
				    mysqli_stmt_bind_param($stmt, "ss", $party, $adharno);
				    
				    if(mysqli_stmt_execute($stmt)) {
				        mysqli_close($conn);
				        session_destroy();
				        header('location:thank-you.php');
				        exit();
				    } else {
				        die("Error saving vote: " . mysqli_error($conn));
				    }
				} else {
				    die("No vote option selected");
				}

				mysqli_close($conn);
				session_destroy();
				

?>