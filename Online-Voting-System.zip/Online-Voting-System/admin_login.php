<?php
session_start();
?>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body {
            margin: 0px;
            padding: 0px;
            background-color: #f0f0f0;
        }
        .login_container {
            width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        .submit-btn:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="login_container">
        <h2>Admin Login</h2>
        <?php
        if(isset($_GET['error'])) {
            echo '<div class="error">'.$_GET['error'].'</div>';
        }
        ?>
        <form action="admin_check.php" method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="submit" name="admin_login" value="Login" class="submit-btn">
            </div>
        </form>
        <p><a href="login.php">Back to User Login</a></p>
    </div>
</body>
</html> 