<?php
session_start();

$host = "localhost:3306";
$user = "root";
$pass = "";
$db = "online_voting_system";

if(isset($_POST['admin_login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $conn = mysqli_connect($host, $user, $pass, $db);
    
    $sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);
    
    if(mysqli_num_rows($result) == 1) {
        $_SESSION['admin'] = true;
        header("location: admin_dashboard.php");
    } else {
        header("location: admin_login.php?error=Invalid credentials");
    }
    
    mysqli_close($conn);
} 