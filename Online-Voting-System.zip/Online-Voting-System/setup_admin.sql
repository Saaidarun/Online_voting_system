-- Drop the existing admin table if it exists
DROP TABLE IF EXISTS admin;

-- Create admin table
CREATE TABLE admin (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100) NOT NULL
);

-- Insert admin credentials
INSERT INTO admin (username, password) VALUES ('admin', 'admin123');

-- Remove vote counts from login page
ALTER TABLE votes ADD COLUMN timestamp DATETIME DEFAULT CURRENT_TIMESTAMP; 